
#include <iostream>
#include <mysql/mysql.h>
#include <string>

using namespace std;

class Student {
public:
    int id;
    string name;
    int age;

    Student(int i, string n, int a) : id(i), name(n), age(a) {}
};

void addStudent(MYSQL* conn, Student s) {
    string query = "INSERT INTO students (id, name, age) VALUES (" 
                    + to_string(s.id) + ", '" 
                    + s.name + "', " 
                    + to_string(s.age) + ")";
    if (mysql_query(conn, query.c_str())) {
        cerr << "Insert Error: " << mysql_error(conn) << endl;
    } else {
        cout << "Student added successfully!" << endl;
    }
}

void viewStudents(MYSQL* conn) {
    if (mysql_query(conn, "SELECT * FROM students")) {
        cerr << "Select Error: " << mysql_error(conn) << endl;
        return;
    }
    MYSQL_RES* res = mysql_store_result(conn);
    MYSQL_ROW row;
    cout << "\nID\tName\tAge\n";
    while ((row = mysql_fetch_row(res)) != NULL) {
        cout << row[0] << "\t" << row[1] << "\t" << row[2] << endl;
    }
    mysql_free_result(res);
}

int main() {
    MYSQL* conn;
    conn = mysql_init(0);
    conn = mysql_real_connect(conn, "localhost", "root", "password", "student_db", 3306, NULL, 0);

    if (conn) {
        cout << "Connected to database successfully!" << endl;
        int choice;
        do {
            cout << "\n1. Add Student\n2. View Students\n3. Exit\nChoice: ";
            cin >> choice;

            if (choice == 1) {
                int id, age;
                string name;
                cout << "Enter ID: "; cin >> id;
                cout << "Enter Name: "; cin >> name;
                cout << "Enter Age: "; cin >> age;
                Student s(id, name, age);
                addStudent(conn, s);
            } else if (choice == 2) {
                viewStudents(conn);
            }
        } while (choice != 3);
    } else {
        cerr << "Database Connection Failed: " << mysql_error(conn) << endl;
    }

    mysql_close(conn);
    return 0;
}
