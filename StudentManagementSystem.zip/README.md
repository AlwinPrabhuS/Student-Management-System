
# Student Management System (C++ + MySQL)

## Overview
This project is a simple Student Management System built using **C++** and **MySQL**.  
It demonstrates:
- Object-oriented programming (OOP)
- Database integration with MySQL
- CLI-based CRUD operations

## Features
- Add new students with ID, name, and age
- View all registered students
- MySQL database connectivity

## Requirements
- MySQL Server
- MySQL Connector/C++
- C++ Compiler (g++)

## Setup
1. Import the SQL script:
   ```bash
   mysql -u root -p < db/student_db.sql
   ```
2. Compile the program:
   ```bash
   g++ src/main.cpp -o build/student_mgmt -lmysqlclient
   ```
3. Run:
   ```bash
   ./build/student_mgmt
   ```

## Author
Alwin Prabhu S
